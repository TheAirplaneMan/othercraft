Minetest Game mod: farming
==========================
See license.txt for license information.

Authors of source code
----------------------
Originally by PilzAdam (MIT)
webdesigner97 (MIT)
Various Minetest Game developers and contributors (MIT)

Authors of media (textures)
---------------------------
Created by PilzAdam (CC BY 3.0):
  farming_bread.png
  farming_soil.png
  farming_soil_wet.png
  farming_soil_wet_side.png
  farming_string.png

Created by BlockMen (CC BY 3.0):
  farming_tool_diamondhoe.png
  farming_tool_mesehoe.png
  farming_tool_bronzehoe.png
  farming_tool_steelhoe.png
  farming_tool_stonehoe.png
  farming_tool_woodhoe.png

Created by MasterGollum (CC BY 3.0):
  farming_straw.png

Created by Gambit (CC BY 3.0):
  farming_wheat.png
  farming_wheat_*.png
  farming_cotton_*.png
  farming_flour.png
  farming_cotton_seed.png
  farming_wheat_seed.png

Created by Napiophelios (CC BY-SA 3.0):
  farming_cotton.png

Created by Extex101 (CC BY-SA 3.0):
  farming_cotton_wild.png

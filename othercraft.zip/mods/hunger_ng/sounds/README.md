# Sounds are licensed differently

## hunger_ng_eat.1.ogg
* Source: https://freesound.org/people/Thedust82/sounds/215639/
* License: Creative Commons 0
* Autor: Thedust82
* Title: Eating a Cracker in the Kitchen

## hunger_ng_eat.2.ogg
* Source: https://freesound.org/people/rkeato/sounds/118050/
* License: Creative Commons By
* Autor: rkeato
* Title: Chomping/Chewing/Crunching on some cheerios, closed AND open mouthed

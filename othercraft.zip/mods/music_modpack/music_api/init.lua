local path = minetest.get_modpath("music_api")
dofile(path .. "/api.lua")

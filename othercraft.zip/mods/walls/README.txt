Minetest Game mod: walls
========================
See license.txt for license information.

Authors of source code
----------------------
Auke Kok <sofar@foo-projects.org> (LGPLv2.1+)
